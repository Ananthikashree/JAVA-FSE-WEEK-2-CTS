package com.api.rest;

public interface RestClient {
    String getResponse();
}

