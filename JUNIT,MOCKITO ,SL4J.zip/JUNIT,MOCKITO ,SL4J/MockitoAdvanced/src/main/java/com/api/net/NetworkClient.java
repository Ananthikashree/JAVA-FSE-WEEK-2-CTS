package com.api.net;

public interface NetworkClient {
    String connect();
}