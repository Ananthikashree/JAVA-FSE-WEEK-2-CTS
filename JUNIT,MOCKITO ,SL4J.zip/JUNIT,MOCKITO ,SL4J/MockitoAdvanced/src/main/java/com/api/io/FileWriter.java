package com.api.io;

public interface FileWriter {
    void write(String content);
}
