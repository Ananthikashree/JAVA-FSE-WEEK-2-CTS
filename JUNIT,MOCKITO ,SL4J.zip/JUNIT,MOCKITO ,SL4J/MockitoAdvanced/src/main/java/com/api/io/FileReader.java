package com.api.io;

public interface FileReader {
    String read();
}