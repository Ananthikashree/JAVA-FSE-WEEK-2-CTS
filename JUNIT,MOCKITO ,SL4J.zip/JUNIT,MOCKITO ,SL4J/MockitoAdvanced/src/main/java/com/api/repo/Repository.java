package com.api.repo;

public interface Repository {
    String getData();
}
