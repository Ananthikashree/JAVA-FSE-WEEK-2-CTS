package com.helper;

public class PerformanceTester {
    public void performTask() throws InterruptedException {
        Thread.sleep(300); // Simulate task delay
    }
}
