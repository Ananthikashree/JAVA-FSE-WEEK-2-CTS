package com.helper;

public class ExceptionThrower {
    public void throwException() {
        throw new IllegalArgumentException("Invalid input!");
    }
}
